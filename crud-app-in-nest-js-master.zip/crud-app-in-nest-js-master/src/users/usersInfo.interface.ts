export interface UserInfos {
    userId:number,
    age:number,
    gender:string,
    mobile:string,
    address:string,
}