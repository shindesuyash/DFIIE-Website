## chnages in database after taken database dumb

Step1 Add you details in core.users 
Add users role of created users 
in core.configuations change localhost: 